package com.example.demo.service;

import com.example.demo.dao.UserDao;
import com.example.demo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserDao userDao;

    @Autowired
    public UserService(UserDao userDao) {
        this.userDao = userDao;
    }

    public User createUser(User user) {
        return userDao.saveUser(user);
    }

    public List<User> getAllUsers() {
        return userDao.getAllUsers();
    }

    public Optional<User> getUserById(String id) {
        return userDao.getUserById(id);
    }

    public User updateUser(String id, User updatedUser) {
        Optional<User> optionalUser = userDao.getUserById(id);
        if (optionalUser.isPresent()) {
            updatedUser.setId(id);
            return userDao.updateUser(updatedUser);
        } else {
            throw new IllegalArgumentException("User not found with ID: " + id);
        }
    }

    public void deleteUser(String id) {
        userDao.deleteUser(id);
    }

    public List<User> searchUsers(String query) {
        return userDao.searchUsers(query);
    }
}
